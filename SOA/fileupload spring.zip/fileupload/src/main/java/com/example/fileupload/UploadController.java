package com.example.fileupload;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/files")
public class UploadController {

    @Autowired
    private FileStorageService fileStorageService;

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        try {
            String fileName = fileStorageService.storeFile(file);
            return ResponseEntity.ok("File uploaded successfully: " + fileName);
        } catch (Exception ex) {
            return ResponseEntity.status(500).body("Could not upload the file: " + ex.getMessage());
        }
    }

    @GetMapping("/list")
    public ResponseEntity<List<String>> listFiles() {
        try {
            List<String> fileNames = new ArrayList<>();
            Files.list(Paths.get("uploads"))
                    .filter(Files::isRegularFile)
                    .forEach(file -> fileNames.add(file.getFileName().toString()));
            return ResponseEntity.ok(fileNames);
        } catch (Exception ex) {
            return ResponseEntity.status(500).body(new ArrayList<>());
        }
    }
}
